# HTML

**HTML** stands for *HyperText Markup Language*.

It is the standard markup language for creating web pages.

## Features

- Easy to learn
- Widely used
- Works with CSS & JavaScript

[Visit HTML Wikipedia](https://en.wikipedia.org/wiki/HTML)
